export interface ISize {
    maxSize: number;
    height: number;
    width: number;
}
