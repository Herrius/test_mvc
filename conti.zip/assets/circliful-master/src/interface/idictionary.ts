export interface IDictionary {
    [key: string]: string | object | number | boolean | [];
    [key: number]: string | object | number | boolean | [];
}
