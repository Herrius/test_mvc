export interface IProgressColor {
    percent: number;
    color: string;
}
