export interface ITag {
    element: object;
    parentId: string;
}
