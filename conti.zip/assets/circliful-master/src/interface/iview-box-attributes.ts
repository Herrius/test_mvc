export interface IViewBoxAttributes {
    minX: number;
    minY: number;
    width: number;
    height: number;
}
