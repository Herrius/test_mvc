export interface ICalculationParams {
    x?: number;
    y?: number;
    startAngle?: number;
    endAngleGrade?: number;
    d?: string;
    radius?: number;
    percent?: number;
    ms?: number;
}
