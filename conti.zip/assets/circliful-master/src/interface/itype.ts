export interface IType {
    type: string;
    value: number | boolean | string | [] | {};
}
