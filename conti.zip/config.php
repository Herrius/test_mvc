<?php

	define("NOMBRE_BLOG", 'Mi Blog');

?>