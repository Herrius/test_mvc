<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/estilo.css"> 
	<title>BUSQUEDA DE AULAS</title>
</head>
<body>

<section class="principal">
	<div class="atras">Atrás</div>
	<h1> BÚSQUEDA DE RESULTADOS POR AULAS</h1>

	<div class="formulario">
		<input type="text" name="caja_busqueda" id="caja_busquedas" class="caja_busqueda" placeholder="Buscar..."></input>	
	</div>

	<div id="datoss"></div>
	
	
</section>



<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/buscars.js"></script>
</body>

</html>