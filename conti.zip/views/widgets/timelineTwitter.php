<a class="twitter-timeline"
  href="https://twitter.com/EdteamLat"
  data-tweet-limit="3"
  data-theme="dark"
  data-width="300"
  data-height="25"
  data-border-color="#a80000"
  data-chrome="nofooter noborders">@EdteamLat
</a>

<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>