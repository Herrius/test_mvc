# Test-Web
Test que evalua los estilos de aprendizaje de los estudiantes universitarios
![image](https://github.com/Herrius/Test-Web/blob/main/imagen_2021-10-08_211130.png)
