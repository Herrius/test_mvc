<?php
	require('core/request.php');
?>